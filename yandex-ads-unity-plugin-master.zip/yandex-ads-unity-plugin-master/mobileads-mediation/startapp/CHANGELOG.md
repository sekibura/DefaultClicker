# Change Log

## Version 7.3.0

#### Updated

* Supported Android StartApp adapter version 5.0.2.0

## Version 7.2.0

#### Updated

* Supported Android StartApp adapter version 5.0.1.0

## Version 7.1.0

#### Updated

* Supported Android StartApp adapter version 5.0.0.0

## Version 7.0.0

#### Updated

* Supported Android StartApp adapter version 4.11.5.1

## Version 6.4.0

#### Updated

* Supported Android StartApp adapter version 4.11.5.0

## Version 6.3.0

#### Updated

* Supported Android StartApp adapter version 4.11.3.0

## Version 6.1.0

#### Updated

* Supported Android StartApp adapter version 4.11.0.3

## Version 6.0.0

#### Updated

* Supported Android StartApp adapter version 4.11.0.2

## Version 2.9.0

#### Updated

* Supported Android StartApp adapter version 4.11.0.1

## Version 2.8.0

#### Updated

* Supported Android StartApp adapter version 4.11.0.0

## Version 2.4.0

#### Updated

* Supported Android StartApp adapter version 4.10.4.0
* Supported Android StartApp SDK version 4.10.4
* Supported Android Yandex Mobile Ads SDK version 5.4.0

## Version 2.3.0

#### Updated

* Supported Android StartApp adapter version 4.10.0.1
* Supported Android Yandex Mobile Ads SDK version 5.3.0
* Supported iOS StartApp adapter version 4.7.3.0
* Supported iOS Yandex Mobile Ads SDK version 5.2.1

## Version 2.2.1

#### Updated

* Supported Android Yandex Mobile Ads SDK version 5.2.1

## Version 2.2.0

#### Updated

* Supported Android StartApp adapter version 4.10.0.0
* Supported Android StartApp SDK version 4.10.0
* Supported Android Yandex Mobile Ads SDK version 5.2.0
* Supported iOS StartApp adapter version 4.7.0.1
* Supported iOS Yandex Mobile Ads SDK version 5.1.0

## Version 2.0.0

#### Updated

* Supported Android StartApp adapter version 4.9.1.0
* Supported Android StartApp SDK version 4.9.1
* Supported Android Yandex Mobile Ads SDK version 5.0.0
* Supported iOS StartApp adapter version 4.7.0.0
* Supported iOS StartApp SDK version 4.7.0
* Supported iOS Yandex Mobile Ads SDK version 5.0.0

## Version 1.1.0

#### Updated

* Supported Android StartApp adapter version 4.8.11.0
* Supported Android StartApp SDK version 4.8.11
* Supported Android Yandex Mobile Ads SDK version 4.4.0
* Supported iOS StartApp adapter version 4.6.1.0
* Supported iOS Yandex Mobile Ads SDK version 4.4.1

## Version 1.0.0

#### Updated

* Supported Android StartApp adapter version 1.12.0
* Supported Android StartApp SDK version 4.6.0
* Supported Android Yandex Mobile Ads SDK version 4.1.0
* Supported iOS StartApp adapter version 0.19.0
* Supported iOS StartApp SDK version 4.6.1
* Supported iOS Yandex Mobile Ads SDK version 4.1.2

## Version 0.6.0

#### Updated

* Supported Android StartApp adapter version 1.9.0
* Supported Android StartApp SDK version 4.6.0
* Supported Android Yandex Mobile Ads SDK version 3.0.0
* Supported iOS StartApp adapter version 0.11.0
* Supported iOS StartApp SDK version 4.5.0
* Supported iOS Yandex Mobile Ads SDK version 2.20.0

## Version 0.5.0

#### Updated

* Supported Android StartApp adapter version 1.8.0
* Supported Android StartApp SDK version 4.6.0
* Supported iOS StartApp adapter version 0.7.0
