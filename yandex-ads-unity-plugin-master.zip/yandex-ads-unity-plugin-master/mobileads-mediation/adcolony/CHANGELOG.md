# Change Log

## Version 7.3.0

#### Updated

* Supported Android AdColony adapter version 4.8.0.14
* Supported iOS AdColony adapter version 4.9.0.19

## Version 7.2.0

#### Updated

* Supported Android AdColony adapter version 4.8.0.13
* Supported iOS AdColony adapter version 4.9.0.16

## Version 7.1.0

#### Updated

* Supported Android AdColony adapter version 4.8.0.12
* Supported iOS AdColony adapter version 4.9.0.14

## Version 7.0.1

#### Updated

* Supported iOS AdColony adapter version 4.9.0.12

## Version 7.0.0

#### Updated

* Supported Android AdColony adapter version 4.8.0.11
* Supported iOS AdColony adapter version 4.9.0.11

## Version 6.4.0

#### Updated

* Supported Android AdColony adapter version 4.8.0.10
* Supported iOS AdColony adapter version 4.9.0.9

## Version 6.3.0

#### Updated

* Supported Android AdColony adapter version 4.8.0.9
* Supported iOS AdColony adapter version 4.9.0.8

## Version 6.1.0

#### Updated

* Supported Android AdColony adapter version 4.8.0.7
* Supported iOS AdColony adapter version 4.9.0.6

#### Updated

## Version 6.0.0

* Supported Android AdColony adapter version 4.8.0.6
* Supported iOS AdColony adapter version 4.9.0.5

## Version 2.9.0

* Supported Android AdColony adapter version 4.8.0.5
* Supported iOS AdColony adapter version 4.9.0.4

#### Updated

## Version 2.8.0

* Supported Android AdColony adapter version 4.8.0.4
* Supported iOS AdColony adapter version 4.9.0.3

## Version 2.4.0

#### Updated

* Supported Android Yandex Mobile Ads SDK version 5.4.0
* Supported Android AdColony adapter version 4.8.0.2

## Version 2.3.0

#### Updated

* Supported Android Yandex Mobile Ads SDK version 5.3.0
* Supported Android AdColony adapter version 4.8.0.1

## Version 2.2.1

#### Updated

* Supported Android Yandex Mobile Ads SDK version 5.2.1

## Version 2.2.0

#### Updated

* Supported Android Yandex Mobile Ads SDK version 5.2.0
* Supported Android AdColony adapter version 4.8.0.0
* Supported Android AdColony SDK version 4.8.0

## Version 2.0.0

#### Updated

* Supported Android Yandex Mobile Ads SDK version 5.0.0
* Supported Android AdColony adapter version 4.6.5.0
* Supported Android AdColony SDK version 4.6.5

## Version 1.0.0

#### Updated

* Supported Android Yandex Mobile Ads SDK version 4.4.0
* Supported Android AdColony adapter version 4.6.4.0
* Supported Android AdColony SDK version 4.6.4
