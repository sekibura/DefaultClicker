# Change Log

## Version 7.3.0

#### Updated

* Supported Android Vungle adapter version 7.1.0.4
* Supported iOS VungleYandexMobileAdsAdapters version 7.4.0.3

## Version 7.2.0

#### Updated

* Supported Android Vungle adapter version 7.1.0.3
* Supported iOS VungleYandexMobileAdsAdapters version 7.4.0.0

## Version 7.1.0

#### Updated

* Supported Android Vungle adapter version 7.1.0.2
* Supported iOS Vungle adapter version 7.3.2.0

## Version 7.0.0

#### Updated

* Supported Android Vungle adapter version 7.1.0.1

## Version 6.4.0

#### Updated

* Supported Android Vungle adapter version 7.1.0.0

## Version 6.3.0

#### Updated

* Supported Android Vungle adapter version 6.12.1.6

## Version 6.1.0

#### Updated

* Supported Android Vungle adapter version 6.12.1.4

## Version 6.0.0

#### Updated

* Supported Android Vungle adapter version 6.12.1.3

## Version 2.9.0

#### Updated

* Supported Android Vungle adapter version 6.12.1.2

## Version 2.8.0

#### Updated

* Supported Android Vungle adapter version 6.12.1.1

## Version 2.4.0

#### Updated

* Supported Android Vungle adapter version 6.12.0.1
* Supported Android Yandex Mobile Ads SDK version 5.4.0

## Version 2.3.0

#### Updated

* Supported Android Vungle adapter version 6.12.0.0
* Supported Android Vungle SDK version 6.12.0
* Supported Android Yandex Mobile Ads SDK version 5.3.0

## Version 2.2.1

#### Updated

* Supported Android Yandex Mobile Ads SDK version 5.2.1

## Version 2.2.0

#### Updated

* Supported Android Vungle adapter version 6.11.0.0
* Supported Android Vungle SDK version 6.11.0
* Supported Android Yandex Mobile Ads SDK version 5.2.0

## Version 2.0.0

#### Updated

* Supported Android Vungle adapter version 6.10.3.0
* Supported Android Vungle SDK version 6.10.3
* Supported Android Yandex Mobile Ads SDK version 5.0.0

## Version 1.0.0

#### Updated

* Supported Android Vungle adapter version 6.9.1.0
* Supported Android Vungle SDK version 6.9.1
* Supported Android Yandex Mobile Ads SDK version 4.4.0
