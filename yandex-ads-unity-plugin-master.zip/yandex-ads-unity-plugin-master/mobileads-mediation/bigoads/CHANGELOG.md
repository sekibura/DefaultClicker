# Change Log

## Version 7.3.0

#### Updated

* Supported Android BigoAds adapter version 4.8.2.0

## Version 7.2.0

#### Updated

* Supported Android BigoAds adapter version 4.8.0.0

## Version 7.1.0

#### Updated

* Supported Android BigoAds adapter version 4.7.4.0

## Version 7.0.0

#### Updated

* Supported Android BigoAds adapter version 4.6.1.0

## Version 6.4.0

#### Updated

* Supported Android BigoAds adapter version 4.5.1.0

## Version 6.3.0

#### Updated

* Supported Android BigoAds adapter version 4.1.2.2

## Version 6.1.0

#### Updated

* Supported Android BigoAds adapter version 4.1.2.0

## Version 6.0.1

#### Updated

* Supported Android BigoAds adapter version 4.0.2.0

## Version 6.0.0

#### Updated

* Supported Android BigoAds adapter version 4.0.2.0

## Version 2.9.0

#### Updated

* Supported Android BigoAds adapter version 2.9.0.2

## Version 2.8.0

#### Updated

* Supported Android BigoAds adapter version 2.9.0.1
