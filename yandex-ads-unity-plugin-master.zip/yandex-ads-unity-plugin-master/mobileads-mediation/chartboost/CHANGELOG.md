# Change Log

## Version 7.3.0

#### Updated

* Supported Android Chartboost adapter version 9.3.1.8
* Supported iOS Chartboost adapter version 9.7.0.8

## Version 7.2.0

#### Updated

* Supported Android Chartboost adapter version 9.3.1.7
* Supported iOS Chartboost adapter version 9.7.0.5

## Version 7.1.0

#### Updated

* Supported Android Chartboost adapter version 9.3.1.6
* Supported iOS Chartboost adapter version 9.7.0.3

## Version 7.0.1

#### Updated

* Supported iOS Chartboost adapter version 9.7.0.1

## Version 7.0.0

#### Updated

* Supported Android Chartboost adapter version 9.3.1.5
* Supported iOS Chartboost adapter version 9.7.0.0

## Version 6.4.0

#### Updated

* Supported Android Chartboost adapter version 9.3.1.4
* Supported iOS Chartboost adapter version 9.6.0.0

## Version 6.3.0

#### Updated

* Supported Android Chartboost adapter version 9.3.1.3
* Supported iOS Chartboost adapter version 9.5.1.1

## Version 6.1.0

#### Updated

* Supported Android Chartboost adapter version 9.3.1.1
* Supported iOS Chartboost adapter version 9.4.0.1

## Version 6.0.0

#### Updated

* Supported Android Chartboost adapter version 9.3.1.0
* Supported iOS Chartboost adapter version 9.4.0.0

## Version 2.9.0

#### Updated

* Supported Android Chartboost adapter version 9.3.0.2
* Supported iOS Chartboost adapter version 9.3.1.0

## Version 2.8.0

#### Updated

* Supported Android Chartboost adapter version 9.3.0.1
* Supported iOS Chartboost adapter version 9.3.0.1

## Version 2.5.0

#### Updated

* Supported Android Chartboost adapter version 9.1.1.0
* Supported Android Chartboost SDK version 9.1.1
* Supported Android Yandex Mobile Ads SDK version 5.5.0

## Version 2.4.0

#### Updated

* Supported Android Chartboost adapter version 9.0.0.0
* Supported Android Chartboost SDK version 9.0.0
* Supported Android Yandex Mobile Ads SDK version 5.4.0

## Version 2.3.0

#### Updated

* Supported Android Chartboost adapter version 8.3.1.2
* Supported Android Yandex Mobile Ads SDK version 5.3.0

## Version 2.2.1

#### Updated

* Supported Android Yandex Mobile Ads SDK version 5.2.1

## Version 2.2.0

#### Updated

* Supported Android Chartboost adapter version 8.3.1.1
* Supported Android Yandex Mobile Ads SDK version 5.2.0

## Version 2.0.0

#### Updated

* Supported Android Chartboost adapter version 8.3.1.0
* Supported Android Chartboost SDK version 8.3.1
* Supported Android Yandex Mobile Ads SDK version 5.0.0

## Version 1.0.0

#### Updated

* Supported Android Chartboost adapter version 8.2.1.0
* Supported Android Chartboost SDK version 8.2.1
* Supported Android Yandex Mobile Ads SDK version 4.4.0
