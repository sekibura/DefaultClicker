# Change Log

## Version 7.3.0

#### Updated

* Supported Android InMobi adapter version 10.7.4.1

## Version 7.2.0

#### Updated

* Supported Android InMobi adapter version 10.7.4.0
* iOS InMobi adapter is unsupported temporary

## Version 7.1.0

#### Updated

* Supported Android InMobi adapter version 10.6.7.1
* Supported iOS InMobi adapter version 10.5.5.10

## Version 7.0.1

#### Updated

* Supported iOS InMobi adapter version 10.5.5.8

## Version 7.0.0

#### Updated

* Supported Android InMobi adapter version 10.6.7.0
* Supported iOS InMobi adapter version 10.5.5.7

## Version 6.4.0

#### Updated

* Supported Android InMobi adapter version 10.6.3.0
* Supported iOS InMobi adapter version 10.5.5.5

## Version 6.3.0

#### Updated

* Supported Android InMobi adapter version 10.6.2.0
* Supported iOS InMobi adapter version 10.5.5.4

## Version 6.1.0

#### Updated

* Supported Android InMobi adapter version 10.5.9.0
* Supported iOS InMobi adapter version 10.5.5.2

## Version 6.0.0

#### Updated

* Supported Android InMobi adapter version 10.5.5.0
* Supported iOS InMobi adapter version 10.5.5.1
